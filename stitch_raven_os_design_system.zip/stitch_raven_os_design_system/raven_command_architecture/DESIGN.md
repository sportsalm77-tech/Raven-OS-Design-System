---
name: Raven Command Architecture
colors:
  surface: '#101417'
  surface-dim: '#101417'
  surface-bright: '#363a3d'
  surface-container-lowest: '#0b0f12'
  surface-container-low: '#181c1f'
  surface-container: '#1c2023'
  surface-container-high: '#262a2e'
  surface-container-highest: '#313539'
  on-surface: '#e0e3e7'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e0e3e7'
  inverse-on-surface: '#2d3134'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#5bde99'
  on-secondary: '#003920'
  secondary-container: '#00a667'
  on-secondary-container: '#00311b'
  tertiary: '#a9d4ef'
  on-tertiary: '#003549'
  tertiary-container: '#8eb8d2'
  on-tertiary-container: '#1c4960'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#79fbb3'
  secondary-fixed-dim: '#5bde99'
  on-secondary-fixed: '#002111'
  on-secondary-fixed-variant: '#005230'
  tertiary-fixed: '#c3e7ff'
  tertiary-fixed-dim: '#a2cce7'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#1e4b62'
  background: '#101417'
  on-background: '#e0e3e7'
  surface-variant: '#313539'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: 4rem
    letterSpacing: -0.04em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: '0'
  body-lg:
    fontFamily: Geist
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Geist
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: Geist
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-mono:
    fontFamily: Space Grotesk
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.05em
  label-code:
    fontFamily: Geist
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system frames academic and institutional management as a high-precision telemetry and operations center. Instead of standard corporate educational software, the aesthetic operates as an avant-garde digital bridge: dark-mode command architecture meeting institutional governance. It projects sovereign authority, algorithmic precision, and calculated intelligence.

The emotional tone balances high-focus vigilance with quiet, decisive mastery. The interface eliminates visual clutter, replacing bright toy-like education tropes with high-contrast surfaces, razor-sharp geometry, dark tactical layers, and focused Raven Gold luminescence. It serves system architects, academic directors, and operational controllers who oversee complex multi-tenant environments.

## Colors

The palette establishes an authoritative hierarchy rooted in a deep, void-like obsidian canvas, punctuated by tactical gold telemetry and functional status indicators.

- **Primary (`#D4AF37` - Raven Gold):** Reserved for focal intelligence, telemetry markers, high-priority operational state locks, and verified institutional certification.
- **Secondary (`#07A869` - Institutional Tactical Green):** Anchors primary system execution, active telemetry streams, confirmed pipeline paths, and real-time positive feedback.
- **Tertiary (`#15445A` - Deep Cyan-Slate):** Structural framing, docked panel fills, persistent chrome, and structural headers.
- **Neutral Canvas (`#090D10` to `#161F26`):** Multi-tier depth baseline. The ground surface rests at `#090D10`, elevated panels rest at `#0E151B`, and high-interaction components surface at `#161F26`.
- **Telemetry Indicators:**
  - Active / Synchronized: `#07A869`
  - Structural Blueprint: `#38BDF8`
  - Staged / Approved: `#F59E0B`
  - Telemetry Divergence / Testing: `#EA580C`
  - Critical Sever / Error: `#EF4444`
  - Synthetic Prototype: `#A855F7`

## Typography

Typography establishes an analytical environment. `Space Grotesk` governs all focal points, structural headers, metric counters, and operational coordinates with strict, engineered geometric angles. `Geist` delivers neutral readability for high-density administrative logs, analytical transcripts, and institutional registries.

All labels, coordinates, and system states utilize upper-cased `Space Grotesk` with intentional letter-spacing to reinforce telemetry instrumentation. Arabic localized counterparts must preserve proportional vertical alignment and structural weight parity without softening baseline rigidity.

## Layout & Spacing

The layout operates on an uncompromising 12-column telemetry grid, architected for high-density information distribution.

- **Desktop (1440px+):** Fixed operational split. 280px pinned operations navigation, 12-column variable analytics field with `1.5rem` gutters, and persistent edge margins of `2.5rem`.
- **Tablet (768px - 1439px):** Adaptive 8-column canvas. Collapses persistent side telemetry into a docked slide-out panel, with `1rem` gutters and `1.5rem` margins.
- **Mobile (<768px):** Single-column stacked telemetry stream. Micro data grids collapse into segmented swipe-rails with strict `1rem` edge safe margins.

Rhythm is strictly modular based on a 4px/8px stepping engine. Internal card padding never exceeds `1.5rem` to prevent dead space in dense institutional monitors.

## Elevation & Depth

Depth is established strictly through tonal luminescent staging and ultra-fine border definition rather than blurry ambient drop shadows. Surfaces advance by rising through obsidian tones and collecting edge-light:

- **Level 0 (Command Floor):** `#090D10`. Deepest dark, absorbs peripheral vision.
- **Level 1 (Docked Structural Units):** `#0E151B` with a 1px solid border of `rgba(212, 175, 55, 0.08)`.
- **Level 2 (Interactive Modules & Panels):** `#141C24` framed by 1px solid `rgba(255, 255, 255, 0.07)`.
- **Level 3 (Tactical Overlays & Drawers):** `#1A242E` flanked by high-definition hairline borders (`rgba(212, 175, 55, 0.25)`) and a tight backlight glow (`0 0 24px -4px rgba(212, 175, 55, 0.12)`).

Shadows are never soft or muddy; they function as precise back-lit halos indicating focal lock.

## Shapes

The design system enforces a restrained, geometric corner radius of 0.25rem (`roundedness: 1`). Elements reject playful circular forms in favor of chiseled, industrial edges. 

- **Base Components:** Inputs, buttons, tags, and badges strictly conform to `0.25rem` (4px).
- **Enclosures:** Structural cards and operational viewports use `0.5rem` (8px).
- **Telemetry Accents:** Corner tabs, active indicator notches, and micro status pips feature pure 90-degree squared angles to evoke precision hardware instrumentation.

## Components

### Action Triggers (Buttons)
- **Primary Execution:** Solid `#D4AF37` fill with `#090D10` ultra-bold typography. 4px radius. Under active state, emits a 2px inner gold hairline with zero elevation blur.
- **Secondary Directive:** Translucent dark canvas (`#141C24`) with a 1px border of `#07A869` and crisp green text.
- **Ghost Tactical:** Frameless; `Space Grotesk` uppercase text with an underline marker that animates horizontally upon targeting.

### Identity Modules (Cards)
- **Telemetry & KPI Units:** Jet surface (`#0E151B`), 1px structural boundary, and top-right micro coordinate indicator in `#D4AF37`. Numerical readouts leverage `Space Grotesk` with tabular spacing.
- **Evidence & Audit Cards:** Segmented with technical dividers (`rgba(255, 255, 255, 0.05)`). Contains a metadata bar running along the top showing timestamp, cryptographic school ID, and validation badge.

### Telemetry Tags & Chips
- Miniature (20px height) tags with `0.25rem` radius. Monospaced tracking.
- States use an inverted dark treatment: dark tinted fills with neon-precise text (e.g., Error: `#EF4444` text on `rgba(239, 68, 68, 0.1)` surface with 1px border of `rgba(239, 68, 68, 0.3)`).

### Data Tables & Registries
- High-density rows with alternating micro-shades. Table headers render in `Space Grotesk` uppercase, bordered by a single crisp line of `rgba(212, 175, 55, 0.2)`. Hover states highlight the entire row in a soft `#15445A` tint.

### School Switcher & Command Drawer
- The multi-tenant tenant selector acts as a military-grade airspace selector: shows school code, operational status node, and real-time active users flanked by gold brackets (`[ ]`).